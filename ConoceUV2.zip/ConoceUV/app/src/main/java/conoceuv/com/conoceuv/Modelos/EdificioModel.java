package conoceuv.com.conoceuv.Modelos;

import java.io.Serializable;

public class EdificioModel implements Serializable {
    public String title;
    public boolean classrooms;
    public boolean laboratory;
}
