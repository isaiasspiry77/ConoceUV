package conoceuv.com.conoceuv.Fragment;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;

public class InfoFragmentActivity extends AppCompatActivity{


}
